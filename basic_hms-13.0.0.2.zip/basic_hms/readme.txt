
Version 13.0.0.1 :
	- Index improvement.

13.0.0.2 ==> fixed issue of x-path in login and added web-icon